package app.web.portfoliofrontendpablomussis;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PortfolioFrontendPablomussisApplication {

	public static void main(String[] args) {
		SpringApplication.run(PortfolioFrontendPablomussisApplication.class, args);
	}

}
