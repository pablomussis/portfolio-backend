package app.web.portfoliofrontendpablomussis;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PortfolioFrontendPablomussisApplicationTests {

	@Test
	void contextLoads() {
	}

}
